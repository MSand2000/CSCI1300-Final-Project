// CSCI1300 Fall 2020
// Author: Miles Sanders
// Recitation 305
#ifndef GAME_H
#define GAME_H


#include "Player.h"
#include "Items.h"
#include "Enemies.h"
#include "Weapons.h"
#include <string>
#include <vector>
using namespace std;
class Game
{
    public:
    // constructor
    Game();
    
    // start game from here
    void loadFile();
    int menu();
    // quit game
    void quitGame();
    // helpers
    int split(string sString, char separator, string arr[], int size);
    int RollD20();
    int RollD12();
    int RollD10();
    int RollD8();
    int RollD6();
    int RollD4();
    int Combat();
    int EnemyAttack(Enemies attacker);
    int AttackEnemy(Weapons Pick, Enemies Target);
    void Merchant();
    

    // setters
    vector<Enemies> generateEnemies(vector<Enemies> generatedEnemies, int numOfEnemies);
    void scavengeForSupplies();

    // getters
    void takeInventory();
    void lootDrop();



    private:
    vector<Weapons> arsenal;
    vector<string> keys;
    vector<string> playerHeldKeys;
    vector<Enemies> enemies;
    Player player;
    vector<Items> availableItems;
    vector<Items> playerInventory;
};
#endif 