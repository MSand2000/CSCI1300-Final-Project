// CSCI1300 Fall 2020
// Author: Miles Sanders
// Recitation 305
#ifndef ITEMS_H
#define ITEMS_H

#include <string>
using namespace std;
class Items
{
    public:
    // constructors
    Items();
    Items(string itemName, int improvementValue);

    //setters
    void setItemName(string itemName);
    void setImprovementValue(int improvementValue);

    //getters
    string getItemName();
    int getImprovementValue();

    private:
    string ItemName;
    int ImprovementValue;
};
#endif