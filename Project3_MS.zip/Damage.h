// CSCI1300 Fall 2020
// Author: Miles Sanders
// Recitation 305
#ifndef DAMAGE_H
#define DAMAGE_H

#include <string>
using namespace std;
class Damage
{
    public:
    //constructors
    Damage();
    Damage(int bD, int sD, int fireD, int frostD);

    //setters
    void setbaseDamage(int bD);
    void setstunDamage(int sD);
    void setfireDamage(int fireD);
    void setfrostDamage(int frostD);    

    //getters
    int getbaseDamage();
    int getstunDamage();
    int getfireDamage();
    int getfrostDamage();


    private:
    int frostDamage;
    int fireDamage;
    int stunDamage;
    int baseDamage;
};
#endif