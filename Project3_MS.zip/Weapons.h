// CSCI1300 Fall 2020
// Author: Miles Sanders
// Recitation 305
#ifndef WEAPONS_H
#define WEAPONS_H

#include "Damage.h"
#include <string>
using namespace std;
class Weapons
{
    public:
    //constructors
    Weapons();
    Weapons(string Name, int bD, int sD, int fireD, int frostD, string boost);

    //setters
    void setWeaponName(string Name); 
    void setWeaponBaseDamage(int bD);    
    void setWeaponStunDamage(int sD);
    void setWeaponFireDamage(int fireD);
    void setWeaponFrostDamage(int frostD);        
    void setWeaponBoost(string boost);

    //getters
    string getWeaponName();
    int getWeaponBaseDamage();
    int getWeaponStunDamage();
    int getWeaponFireDamage();
    int getWeaponFrostDamage();
    string getWeaponBoost();


    private:
    string weaponName;
    int weaponBase;
    int weaponFrost;
    int weaponFire;
    int weaponStun;
    string weaponboost;
};
#endif