// CSCI1300 Fall 2020
// Author: Miles Sanders
// Recitation 305
#include "Player.h"
#include <iostream>

using namespace std;

Player::Player()
{
    maxHealth = 0;
    currentHealth = 0;
    armorRating = 0;
    damageRating = 0;
    hacksilver = 0;
    appleOfEdun = 0;
    skapSlag = 0;
    worldTreeDew = 0;
    asgardianSteel = 0;
}

Player::Player(int H, int A, int D, int HS, int AE, int SS, int WTD, int AS)
{
    maxHealth = H;
    currentHealth = H;
    armorRating = A;
    damageRating = D;
    hacksilver = HS;
    appleOfEdun = AE;
    skapSlag = SS;
    worldTreeDew = WTD;
    asgardianSteel = AS;
}

int Player::getMaxHealth()
{
    return maxHealth;
}

void Player::setMaxHealth(int H)
{
    maxHealth = H;
}

int Player::getCurrentHealth()
{
    return currentHealth;
}

void Player::setCurrentHealth(int C)
{
    currentHealth = currentHealth - C;
}

int Player::getArmorRating()
{
    return armorRating;
}

void Player::setArmorRating(int A)
{
    armorRating = A;
}

int Player::getDamageRating()
{
    return damageRating;
}

void Player::setDamageRating(int D)
{
    damageRating = D;
}

int Player::getHackSilver()
{
    return hacksilver;
}

void Player::setHackSilver(int HS)
{
    hacksilver = HS;
}

int Player::getAppleOfEdun()
{
    return appleOfEdun;
}

void Player::setAppleOfEdun(int AE)
{
    appleOfEdun = AE;
}

int Player::getSkapSlag()
{
    return skapSlag;
}

void Player::setSkapSlag(int SS)
{
    skapSlag = SS;
}

int Player::getWorldTreeDew()
{
    return worldTreeDew;
}

void Player::setWorldTreeDew(int WTD)
{
    worldTreeDew = WTD;
}

int Player::getAsgardianSteel()
{
    return asgardianSteel;
}

void Player::setAsgardianSteel(int AS)
{
    asgardianSteel = AS;
}

void Player::addHealth(int C)
{
    currentHealth = currentHealth + C;
    if (currentHealth > maxHealth)
    {
        currentHealth = maxHealth;
    }
}