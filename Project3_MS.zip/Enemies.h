// CSCI1300 Fall 2020
// Author: Miles Sanders
// Recitation 305
#ifndef ENEMIES_H
#define ENEMIES_H

#include "Damage.h"
#include <string>
using namespace std;
class Enemies
{
    public:
    //constructors
    Enemies();
    Enemies(string enemyType, string enemyBoost, string enemyWeakness, 
    int enemyDamageRating, int enemyBaseDamage, int enemyBoostDamage, 
    int enemyArmorRating, int enemyMaxHealth);

    //setters
    void setEnemyType(string enemyType);
    void setEnemyBoost(string enemyBoost);
    void setEnemyWeakness(string enemyWeakness);
    void setEnemyDamageRating(int enemyDamageRating);
    void setEnemyBaseDamage(int enemyBaseDamage);
    void setEnemyBoostDamage(int enemyBoostDamage);
    void setEnemyArmorRating(int enemyArmorRating);
    void setEnemyMaxHealth(int enemyMaxHealth);
    void setEnemyCurrentHealth(int C);

    //getters
    string getEnemyType();
    string getEnemyBoost();
    string getEnemyWeakness();
    int getEnemyDamageRating();
    int getEnemyBaseDamage();
    int getEnemyBoostDamage();
    int getEnemyArmorRating();
    int getEnemyMaxHealth();
    int getEnemyCurrentHealth();


    private:
    string EnemyType;
    string EnemyBoost;
    string EnemyWeakness;
    int EnemyDamageRating;
    int EnemyBaseDamage;
    int EnemyBoostDamage;
    int EnemyArmorRating;
    int EnemyMaxHealth;
    int EnemyCurrentHealth;
};
#endif  