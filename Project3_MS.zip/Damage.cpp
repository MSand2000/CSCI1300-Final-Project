// CSCI1300 Fall 2020
// Author: Miles Sanders
// Recitation 305
#include "Damage.h"
#include <iostream>
#include <string>

using namespace std;

Damage::Damage()
{
    frostDamage = 0;
    fireDamage = 0;
    stunDamage = 0;
    baseDamage= 0;
}
Damage::Damage(int bD, int sD, int fireD, int frostD)
{
    frostDamage = frostD;
    fireDamage = fireD;
    stunDamage = sD;
    baseDamage= bD;
}

int Damage::getbaseDamage()
{
    return baseDamage;
}
void Damage::setbaseDamage(int bD)
{
    baseDamage= bD;
}
int Damage::getstunDamage()
{
    return stunDamage;
}
void Damage::setstunDamage(int sD)
{
    stunDamage = sD;
}
int Damage::getfireDamage()
{
    return fireDamage;
}
void Damage::setfireDamage(int fireD)
{
    fireDamage = fireD;
}
int Damage::getfrostDamage()
{
    return frostDamage;
}
void Damage::setfrostDamage(int frostD)
{
    frostDamage = frostD;
}