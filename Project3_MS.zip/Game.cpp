// CSCI1300 Fall 2020
// Author: Miles Sanders
// Recitation 305
#include "Game.h"
#include "Player.h"
#include "Items.h"
#include "Enemies.h"
#include "Weapons.h"
#include <iostream>
#include <string>
#include <fstream>
#include <array>
#include <vector>

using namespace std;

void Game::loadFile()
{
    ifstream inFile;
    string line = "";
    int H;
    int A;
    int D;
    int HS;
    int AE;
    int SS;
    int WTD;
    int AS;
    string arr[8]; 
    inFile.open("playerStats.txt");
    if (inFile.is_open())
    {
        while (getline(inFile, line))
        {
            if (line != "" && line[0] != '~')
            {
                split(line, ',', arr, 8); 
                H = stoi(arr[0]);
                A = stoi(arr[1]);
                D = stoi(arr[2]);
                HS = stoi(arr[3]);
                AE = stoi(arr[4]);
                SS = stoi(arr[5]);
                WTD = stoi(arr[6]);
                AS = stoi(arr[7]); 
                player = Player(H,A,D,HS,AE,SS,WTD,AS); //creates player for game
            }
        }
    }
    inFile.close();

    string weaponName;
    int bD;
    int sD;
    int fireD;
    int frostD;
    string boost;
    string weaponstats[6];
    int arsenalIDX = 0;
    inFile.open("weapons.txt");
    if (inFile.is_open())
    {
        while (getline(inFile, line))
        {
            if (line != "" && line[0] != '~')
            {
                split(line, ',', weaponstats, 5); 
                weaponName = weaponstats[0];
                bD = stoi(weaponstats[1]);
                sD = stoi(weaponstats[2]);
                fireD = stoi(weaponstats[3]); 
                frostD = stoi(weaponstats[4]);
                boost = weaponstats[6];
                arsenal.push_back(Weapons(weaponName, bD, sD, fireD, frostD, boost)); //creates arsenal of weapons for player
                arsenalIDX++; 
            }
        }
    }
    inFile.close();

    string enemyType;
    string enemyBoost;
    string enemyWeakness;
    int enemyDamageRating; 
    int enemyBaseDamage; 
    int enemyBoostDamage; 
    int enemyArmorRating;
    int enemyMaxHealth;
    string stats[8];
    int enemyIDX = 0;
    inFile.open("enemyStats.txt");
    if (inFile.is_open())
    {
        while (getline(inFile, line))
        {
            if (line != "" && line[0] != '~')
            {
                split(line, ',', stats, 8); 
                enemyType = stats[0];
                enemyBoost = stats[1];
                enemyWeakness = stats[2];
                enemyDamageRating = stoi(stats[3]);
                enemyBaseDamage = stoi(stats[4]);
                enemyBoostDamage = stoi(stats[5]); 
                enemyArmorRating = stoi(stats[6]);
                enemyMaxHealth = stoi(stats[7]);
                enemies.push_back(Enemies(enemyType, enemyBoost, enemyWeakness, enemyDamageRating, enemyBaseDamage, enemyBoostDamage, enemyArmorRating, enemyMaxHealth));
                enemyIDX++; // creates a reference vector of enemies that can be called later on
            }
        }
    }
    inFile.close();

    string itemName;
    int itemImprovementValue;
    string itemStats[2];
    int itemIDX = 0;
    inFile.open("items.txt");
    if (inFile.is_open())
    {
        while (getline(inFile, line))
        {
            if (line != "" && line[0] != '~')
            {
                split(line, ',', itemStats, 2); 
                itemName = itemStats[0];
                itemImprovementValue = stoi(itemStats[1]);
                availableItems.push_back(Items(itemName, itemImprovementValue));
                itemIDX++; //creates a reference vector of items that can be called later on
            }
        }
    }
    inFile.close();

    for (int i = 0; i < 3; i++)
    {
        playerInventory.push_back(availableItems[i]); //gives player starting items
    }

    string keyName;
    inFile.open("keys.txt");
    if (inFile.is_open())
    {
        while (getline(inFile, line))
        {
            if (line != "" && line[0] != '~')
            {
                keyName = line;
                keys.push_back(keyName);//creates a reference vector for story keys that can be called later on
            }
        }
    }
    inFile.close();
}

Game::Game() // clears private data members for new play through
{
    arsenal.clear();
    keys.clear();
    playerHeldKeys.clear();
    enemies.clear();
    player = Player();
    availableItems.clear();
    playerInventory.clear();
}

int Game::menu() //main interface for player, references all other helper functions from here
{
    int keyIDX = 0;
    cout << "You and your son Atreus have begun your journey to scatter your spouses ashes off the tallest peak in the nine realms. With your friend, the talking head Mimir, your first course of action is to follow the river near your home down to the lake of nine, where the god Tyr has built his realm travel room that houses a Bifrost, capable of realm travel to all branches of the world tree." << endl;
    bool flag = false;
    bool scavenge = false;
    while(flag == false)
    {
        cout << "Select a numerical option:" << endl;
        cout << "======Actions=====" << endl;
        cout << "1. Quit" << endl;
        cout << "2. Begin Journey" << endl;
        cout << "3. Take Inventory" << endl;
        if (scavenge == false)
        {
            cout << "4. Scavenge for supplies" << endl;
        }

        string input;
        getline(cin, input);
        int num = stoi(input);
        switch(num)
        {
            case(1):
            quitGame();
            return 0;
            break;

            case(2):
            cout << "You continue downriver." << endl;
            flag = true;
            break;

            case(3):
            takeInventory();
            break;

            case(4):
            scavenge = true;
            scavengeForSupplies();
            break;
            

            default: //default condition
            cout << "Invalid input." << endl;
            break;
        }
    }

    scavenge = false;
    flag = false;
    bool flag2 = false;
    int outcome;
    while (flag == false)
    {
        outcome = Combat();
        if (outcome == 1)
        {
            cout << "You are forced to retreat." << endl;
            cout << endl;
            while (flag2 = false)
            {
                cout << "do you..." << endl;
                if (scavenge == false)
                {
                    cout << "1. Scavenge for supplies" << endl;
                }
                cout << "2. go again" << endl;
                cout << "3. quit game" << endl;
                string input;
                getline(cin, input);
                int num = stoi(input);
                switch(num)
                {
                    case(1):
                    scavengeForSupplies();
                    scavenge = true;
                    break;
                    case(2):
                    cout << "you go again!" << endl;
                    flag2 = true;
                    break;
                    case(3):
                    quitGame();
                    return 0;
                    break;
                    default:
                    cout << "Invalid input." << endl;
                    break;
                }
            }
        }
        if (outcome == 2)
        {
            cout << "You emerge victorious." << endl;
            scavenge = false;
            flag = true;
        }
    }

    cout << "You have arrived at the lake of nine! From the beach, Tyr's Temple sits at its center with a bridge leading to its main hall from the shore." << endl;
    cout << "You open the temple doors to find two dwarves working at their shop." << endl;
    cout << endl;
    cout << "Brok - Welcome! What'll it be?" << endl;
    cout << "Sindri - We sell whatever you need!" << endl;
    cout << endl;
    cout << "The realm travel room hums with magic, but it seems to be limitied to only one other realm." << endl;
    cout << "Mimir - Jotunheim is blocked off. Sealed away by three travel runes." << endl;
    cout << "Atreus - looks like we can go three different ways. The bifrost is capable of travel Alfheim, we can go to the mountain beyond the temple, or we could go search the surrounding woods." << endl;
    cout << "Mimir - chances are that's where we'll find those runes." << endl;
    bool flag3 = false;
    scavenge = false;
    bool alfheim = false;
    bool mountain = false;
    bool woods = false;
    while(flag3 == false)
    {
        cout << "Select a numerical option:" << endl;
        cout << "======Actions=====" << endl;
        cout << "1. Quit Game" << endl;
        if (alfheim == false)
        {
            cout << "2. Go to Alfheim" << endl;
        }
        if (mountain == false)
        {
            cout << "3. Climb the mountain" << endl;
        }
        if (woods == false)
        {
            cout << "4. Explore the woods" << endl;
        }
        cout << "5. Take Inventory" << endl;
        cout << "6. Inspect Realm Travel Room" << endl;
        if (scavenge == false)
        {
            cout << "7. Scavenge for supplies" << endl;
        }
        cout << "8. Brok and Sindri's Shop" << endl;

        string input;
        getline(cin, input);
        int num = stoi(input);
        switch(num)
        {
            case(1):
            quitGame();
            return 0;
            break;

            case(2):
            cout << "You activate the bifrost and the room is flooded with blue light. Walking out of the temple, the world looks completely different! Tyr's Bridge is covered in red luminescent vines and the sky is flooded with a bright white light." << endl;
            cout << "Following Tyr's Bridge you come to a clearing." << endl;
            scavenge = false;
            flag = false;
            flag2 = false;
            while (flag == false)
            {
                outcome = Combat();
                if (outcome == 1)
                {
                    cout << "You are forced to retreat." << endl;
                    cout << endl;
                    while (flag2 = false)
                    {
                        cout << "do you..." << endl;
                        if (scavenge == false)
                        {
                            cout << "1. Scavenge for supplies" << endl;
                        }
                        cout << "2. go again" << endl;
                        cout << "3. quit game" << endl;
                        string input;
                        getline(cin, input);
                        int num = stoi(input);
                        switch(num)
                        {
                            case(1):
                            scavengeForSupplies();
                            scavenge = true;
                            break;
                            case(2):
                            cout << "you go again!" << endl;
                            flag2 = true;
                            break;
                            case(3):
                            quitGame();
                            return 0;
                            break;
                            default:
                            cout << "Invalid input." << endl;
                            break;
                        }
                    }
                }
                if (outcome == 2)
                {
                    cout << "You emerge victorious." << endl;
                    scavenge = false;
                    flag = true;
                }
            }
            cout << "You come across a chest hidden beneath the vines. Inside you find one of the three runes!" << endl;
            playerHeldKeys.push_back(keys.at(keyIDX));
            keyIDX++;
            alfheim = true;
            cout << "~you return to Midgard~" << endl;
            break;

            case(3):
            cout << "You scale the once occupied dwarven stronghold to its peak." << endl;
            cout << "Atreus - Wow! you can see home from here!" << endl;
            scavenge = false;
            flag = false;
            flag2 = false;
            while (flag == false)
            {
                outcome = Combat();
                if (outcome == 1)
                {
                    cout << "You are forced to retreat." << endl;
                    cout << endl;
                    while (flag2 = false)
                    {
                        cout << "do you..." << endl;
                        if (scavenge == false)
                        {
                            cout << "1. Scavenge for supplies" << endl;
                        }
                        cout << "2. go again" << endl;
                        cout << "3. quit game" << endl;
                        string input;
                        getline(cin, input);
                        int num = stoi(input);
                        switch(num)
                        {
                            case(1):
                            scavengeForSupplies();
                            scavenge = true;
                            break;
                            case(2):
                            cout << "you go again!" << endl;
                            flag2 = true;
                            break;
                            case(3):
                            quitGame();
                            return 0;
                            break;
                            default:
                            cout << "Invalid input." << endl;
                            break;
                        }
                    }
                }
                if (outcome == 2)
                {
                    cout << "You emerge victorious." << endl;
                    scavenge = false;
                    flag = true;
                }
            }
            cout << "You spot an altar. On top of it you find one of the three runes!" << endl;
            playerHeldKeys.push_back(keys.at(keyIDX));
            keyIDX++;
            mountain = true;
            cout << "~you return to Tyrs Temple~" << endl;
            break;

            case(4):
            cout << "Exploring the woods, you smell fresh rain on tree bark and listen to the birds sing." << endl;
            cout << "All of the sudden, everything goes quiet. There's a faint rustling in the brush..." << endl;
            scavenge = false;
            flag = false;
            flag2 = false;
            while (flag == false)
            {
                outcome = Combat();
                if (outcome == 1)
                {
                    cout << "You are forced to retreat." << endl;
                    cout << endl;
                    while (flag2 = false)
                    {
                        cout << "do you..." << endl;
                        if (scavenge == false)
                        {
                            cout << "1. Scavenge for supplies" << endl;
                        }
                        cout << "2. go again" << endl;
                        cout << "3. quit game" << endl;
                        string input;
                        getline(cin, input);
                        int num = stoi(input);
                        switch(num)
                        {
                            case(1):
                            scavengeForSupplies();
                            scavenge = true;
                            break;
                            case(2):
                            cout << "you go again!" << endl;
                            flag2 = true;
                            break;
                            case(3):
                            quitGame();
                            return 0;
                            break;
                            default:
                            cout << "Invalid input." << endl;
                            break;
                        }
                    }
                }
                if (outcome == 2)
                {
                    cout << "You emerge victorious." << endl;
                    flag = true;
                    scavenge = false;
                }
            }
            cout << "Something catches your eye stashed beneath the roots of a great oak tree..." << endl;
            cout << "You uncover one of the three travel runes!" << endl;
            playerHeldKeys.push_back(keys.at(keyIDX));
            keyIDX++;
            woods = true;
            cout << "~you return to Tyrs Temple~" << endl;
            break;

            case(5):
            takeInventory();
            break;

            case(6):
            if (playerHeldKeys.size() == 3)
            {
                if (playerHeldKeys.at(0) == keys.at(0))
                {
                    if (playerHeldKeys.at(1) == keys.at(1))
                    {
                        if (playerHeldKeys.at(2) == keys.at(2))
                        {
                            cout << "The locks slowly turn to dust as you present the runes before them" << endl;
                            cout << "Atreus - We can go to Jotunheim now!" << endl;
                            cout << "The room floods with blue light as you activate the bifrost. You open the temple doors to find yourself in Jotunheim! Land of the Giants." << endl;
                            cout << "Atreus - We made it!" << endl;
                            cout << "~The End~" << endl;
                            quitGame();
                            flag3 = true;
                        }
                    }
                }
            }
            else
            {
                cout << "Mimir - Looks like you havent got what you need yet." << endl;
            }
            
            break;

            case(7):
            scavenge = true;
            scavengeForSupplies();
            break;

            case(8):
            Merchant();
            break;

            default: //default condition
            cout << "Invalid input." << endl;
            break;
        }
    }
    return 1;
}

void Game::lootDrop() 
{
    int roll;
    int loot;
    int temp;
    roll = RollD10();
    if (roll>=5)
    {
        srand(time(NULL));
        loot = rand() % 25 + 10;
        temp = player.getHackSilver();
        temp += loot;
        player.setHackSilver(temp);
        cout << "HackSilver +" << loot << endl;
    }
    roll = RollD10();
    if (roll>=5)
    {
        srand(time(NULL));
        loot = rand() % 5 + 1;
        temp = player.getAppleOfEdun();
        temp += loot;
        player.setAppleOfEdun(temp);
        cout << "Apple of Edun +" << loot << endl;
    }  
    roll = RollD10();
    if (roll>=5)
    {
        srand(time(NULL));
        loot = rand() % 5 + 1;
        temp = player.getSkapSlag();
        temp += loot;
        player.setSkapSlag(temp);
        cout << "Skap Slag +" << loot << endl;
    }
    if (roll>=5)
    {
        srand(time(NULL));
        loot = rand() % 5 + 1;
        temp = player.getWorldTreeDew();
        temp += loot;
        player.setWorldTreeDew(temp);  
        cout << "World Tree Dew +" << loot << endl;
    }
    if (roll>=5)
    {
        srand(time(NULL));
        loot = rand() % 5 + 1;
        temp = player.getAsgardianSteel();
        temp += loot;
        player.setAsgardianSteel(temp);
        cout << "Asgardian Steel +" << loot << endl;  
    }
}

void Game::quitGame()
{
    cout << "Thanks for playing!" << endl;
    string file = "endGameStats.txt";
    ofstream outfile;
    outfile.open(file);
    if(outfile.is_open())
    {
        outfile << "~Max Health, Armor Rating, Damage Rating, Hack Silver, Apple of Edun, Skapslag, World Tree Dew, Asgardian Steel" << endl;
        outfile << player.getMaxHealth() << ", " << player.getArmorRating() << ", " << player.getDamageRating() << ", " << player.getHackSilver() << ", " << player.getAppleOfEdun() << ", " << player.getSkapSlag() << ", " <<player.getWorldTreeDew() <<", " << player.getAsgardianSteel()<<endl;
    }
    outfile.close();
}

void Game::scavengeForSupplies()
{
    Items tempItem;//test
    int size = playerInventory.size();//test 
    int loot = 0;
    int roll = RollD20();
    if (roll > 10)
    {
        playerInventory.push_back(availableItems.at(0));
        cout << "Youre in luck!" << endl;
        cout << "Supplies found: "<< endl;
        cout << playerInventory.at(size).getItemName() << endl;
    }
    else
    {
        cout << "Looks like someone else got here first." << endl;
        cout << "No supplies found." << endl;
    }
}

void Game::Merchant()
{
    bool flag = false;
    while (flag == false)
    {
        cout << "===The Huldra Brothers===" << endl;
        cout << "1. Weapon Upgrade (5 Asgardian Steel)" << endl;
        cout << "2. Armor Upgrade (5 Skapslag)" << endl;
        cout << "3. Health Upgrade (5 World Tree Dew)" << endl;
        cout << "4. Damage Upgrade (10 Apple Of Edun)" << endl;
        cout << "5. Purchase Healing Stone" << endl;
        cout << "6. Leave" << endl;
        string input;
        getline(cin, input);
        int num = stoi(input);
        int measure;
        int measure2;
        bool flag2;
        switch(num)
        {
            case(1):
            measure = player.getAsgardianSteel();
            if (measure >= 5)
            {
                measure -= 5;
                player.setAsgardianSteel(measure);
                for (int i = 0; i < 4; i++)
                {
                    measure2 = arsenal.at(i).getWeaponBaseDamage();
                    measure2++;
                    arsenal.at(i).setWeaponBaseDamage(measure2);
                }
                cout << "Arsenal Base Damage Upgraded By 1" << endl;
            }
            else
            {
                cout << "Not enough material. Need 5" << endl;
            }
            break;

            case(2):
            measure = player.getSkapSlag();
            if (measure >= 5)
            {
                measure -= 5;
                player.setSkapSlag(measure);
                measure2 = player.getArmorRating();
                measure2++;
                player.setArmorRating(measure2);
                cout << "Armor Rating Upgraded By 1" << endl;
            }
            else
            {
                cout << "Not enough material. Need 5" << endl;
            }
            break;

            case(3):
            measure = player.getWorldTreeDew();
            if (measure >= 5)
            {
                measure -= 5;
                player.setWorldTreeDew(measure);
                measure2 = player.getMaxHealth();
                measure2 += 5;
                player.setMaxHealth(measure2);
                cout << "Max Health Upgraded By 5" << endl;
            }
            else
            {
                cout << "Not enough material. Need 5" << endl;
            }
            break;

            case(4):
            measure = player.getAppleOfEdun();
            if (measure >= 10)
            {
                measure -= 10;
                player.setAppleOfEdun(measure);
                measure2 = player.getDamageRating();
                measure2--;
                player.setDamageRating(measure2);
                cout << "Damage Rating Decreased By 1" << endl;
            }
            else
            {
                cout << "Not enough material. Need 5" << endl;
            }
            break;

            case(5):
            flag2 = false;
            while (flag2 == false)
            {
                cout << "What Item do you need?: " << endl;
                cout << "1. healingStone 50 HackSilver" << endl;
                cout << "2. go back" << endl;
                string input;
                getline(cin, input);
                int num = stoi(input);
                switch (num)
                {
                    case(1):
                    measure = player.getHackSilver();
                    if (measure > 50)
                    {
                        measure -= 50;
                        player.setHackSilver(measure);
                        playerInventory.push_back(availableItems.at(0));
                    }
                    else
                    {
                        cout << "Not enough Hacksilver" << endl;
                    }
                    break;

                    case(2):
                    flag2 = true;

                    default: //default condition
                    cout << "Invalid input." << endl;
                    break;
                }
            }
            break;

            case(6):
            flag = true;
            cout << "Brok - bye now!" << endl;
            break;

            default: //default condition
            cout << "Invalid input." << endl;
            break;
        }
    }
}

vector<Enemies> Game::generateEnemies(vector<Enemies> generatedEnemies, int numOfEnemies)
{
    srand(time(NULL));
    for (int i = 0; i < numOfEnemies; i++)
    {
        int roll = rand() % 5 + 0;
        // cout << roll << endl;
        generatedEnemies.push_back(enemies.at(roll));
        // cout << generatedEnemies.at(i).getEnemyType() << endl; 
    }
    return generatedEnemies;
}

int Game::Combat()
{
    int numOfEnemies = 3;
    vector<Enemies> generatedEnemies;
    generatedEnemies = generateEnemies(generatedEnemies, numOfEnemies);
    int outcome;
    cout << "Atreus - LOOK OUT!" << endl;
    cout << "~COMBAT ENCOUNTER~" << endl;
    bool flag = false;
    bool flag2 = false;
    while(flag == false)
    {
        cout << "You survey your surroundings for enemies..." << endl;
        cout << endl;
        for (int i = 0; i < generatedEnemies.size(); i++)
        {
            cout << generatedEnemies.at(i).getEnemyType() << endl;
            cout << "Current Health: "<< generatedEnemies.at(i).getEnemyCurrentHealth() << endl;
            cout << "Deals " << generatedEnemies.at(i).getEnemyBoostDamage() << " extra points of " << generatedEnemies.at(i).getEnemyBoost() << " damage." << endl;
            cout << endl;
        }
        while (flag2 == false)
        {
            cout << "CURRENT HEALTH: " << player.getCurrentHealth() << endl;
            cout << endl;
            cout << "What is your next move?" << endl;
            cout << "======Actions=====" << endl;
            cout << "1. Attack" << endl;
            cout << "2. Use Healing Stone" << endl;
            string input;
            getline(cin, input);
            int num = stoi(input);
            int count;
            string test = "";
            switch(num)
            {
                case(1):
                flag2 = true;
                break;

                case(2):
                if (playerInventory.size() == 0)
                {
                    cout << "No healing stones in inventory." << endl;
                }
                else
                {
                    cout << "Current Inventory: " << endl;
                    for (int i = 0; i < 1; i++)
                    {
                        count = 0;
                        test = availableItems.at(i).getItemName();
                        for (int i = 0; i < playerInventory.size(); i++)
                        {
                            if (test == playerInventory.at(i).getItemName())
                            {
                                count++;
                            }
                        }
                        cout << test << ": " << count << endl;
                    }
                    bool stone = false;
                    while (stone == false)
                    {
                        cout << "Use Stone?" << endl;
                        cout << "1. Yes" << endl;
                        cout << "2. No" << endl;
                        string input;
                        int bump = 0;
                        getline(cin, input);
                        int num = stoi(input);
                        switch(num)
                        {
                            case(1):
                            bump = availableItems.at(0).getImprovementValue();
                            player.addHealth(bump);
                            playerInventory.pop_back();

                            stone = true;
                            break;

                            case(2):
                            cout << "No stone used." << endl;
                            stone = true;
                            break;

                            default: //default condition
                            cout << "Invalid input." << endl;
                            break;  
                        }
                    }
                }
                break;

                default: //default condition
                cout << "Invalid input." << endl;
                break;  
            }
        }
        Weapons pick;
        while(flag2 == true)
        { 
            cout << "Pick your weapon:" << endl;
            for (int i = 0; i < 4; i++)
            {
                cout << i+1 << ". " << arsenal.at(i).getWeaponName() << endl;
            }
            cout << endl;
            string input;
            int num;
            getline(cin, input);
            num = stoi(input);
            switch(num)
            {
                case(1):
                pick = arsenal.at(0);
                flag2 = false;
                break;

                case(2):
                pick = arsenal.at(1);
                flag2 = false;
                break;
                
                case(3):
                pick = arsenal.at(2);
                flag2 = false;
                break;
                
                case(4):
                pick = arsenal.at(3);
                flag2 = false;
                break;

                default: //default condition
                cout << "Invalid input." << endl;
                break;
            } 
        }
        Enemies target;
        int num;
        bool flag3 = false;
        while(flag3 == false)
        { 
            cout << "Choose Your Target:" << endl;
            for (int i = 0; i < generatedEnemies.size(); i++)
            {
                cout << i+1 << ". " << generatedEnemies.at(i).getEnemyType() << endl;
            }
            cout << endl;
            string input;
            getline(cin, input);
            num = stoi(input);
            num--;
            if (num >= 0 && num < generatedEnemies.size())
            {
                target = generatedEnemies.at(num);
                flag3 = true;
            }   
            else
            {
                cout << "Invalid Input" << endl;
            }
        }
        cout << target.getEnemyType() << endl; //test
        cout << "You attack with " << pick.getWeaponName() << endl;
        int damage = AttackEnemy(pick, target);
        cout << "And deal " << damage << " points of damage." << endl;
        cout << endl;
        generatedEnemies.at(num).setEnemyCurrentHealth(damage);
        for (int i = 0; i < generatedEnemies.size(); i++)
        {
            if (generatedEnemies.at(i).getEnemyCurrentHealth() <= 0)
            {
                generatedEnemies.erase(generatedEnemies.begin() + i);
                lootDrop();
            }
        }
        for (int i = 0; i < generatedEnemies.size(); i++)
        {
            cout << generatedEnemies.at(i).getEnemyType() << " attacks!" << endl;
            damage = EnemyAttack(generatedEnemies.at(i));
            cout << "And deals " << damage << " points of damage." << endl;
            player.setCurrentHealth(damage);
            cout << endl;
        }
        if (generatedEnemies.size() == 0)
        {
            outcome = 2;
            flag = true;
        }
        if (player.getCurrentHealth() <= 0)
        {
            int temp;
            temp = player.getCurrentHealth();
            temp -= 50;
            player.addHealth(temp);
            outcome = 1;
            flag = true;
        }
    }
    return outcome;
}

int Game::EnemyAttack(Enemies attacker)
{
    int damage = 0;
    int roll = RollD20();
    if (roll == 20)
    {
        cout << "ENEMY CRITICAL HIT" << endl;
        damage = attacker.getEnemyBaseDamage();
        damage = damage*2;
    }
    else if (roll > attacker.getEnemyDamageRating())
    {
        damage = attacker.getEnemyBaseDamage();
        roll = RollD20();
        if  (roll > attacker.getEnemyDamageRating())
        {
            damage += attacker.getEnemyBoostDamage();
        }
    }
    return damage;
}

int Game::AttackEnemy(Weapons Pick, Enemies Target)
{
    int damage = 0;
    bool special = false;
    if (Pick.getWeaponBoost() == Target.getEnemyWeakness())
    {
        special = true;
    }
    int roll = RollD20();
    if (roll == 20)
    {
        cout << "CRITICAL HIT" << endl;
        damage = Pick.getWeaponBaseDamage();
        damage = damage*2;
        if (special == true)
        {
            damage += Pick.getWeaponFrostDamage();
            damage += Pick.getWeaponFireDamage();
            damage += Pick.getWeaponStunDamage();
        }
    }
    else if (roll > player.getDamageRating())
    {
        damage = Pick.getWeaponBaseDamage();
        if (special == true)
        {
            damage += Pick.getWeaponFrostDamage();
            damage += Pick.getWeaponFireDamage();
            damage += Pick.getWeaponStunDamage();
        }
    }
    else
    {
        cout << "Attack Failure" << endl;
    }
    return damage;
}

int Game::RollD20()
{
    srand(time(NULL));
    int roll = rand() % 20 + 1;
    return roll;
}

int Game::RollD12()
{
    srand(time(NULL));
    int roll = rand() % 12 + 1;
    return roll;
}

int Game::RollD10()
{
    srand(time(NULL));
    int roll = rand() % 10 + 1;
    return roll;
}

int Game::RollD8()
{
    srand(time(NULL));
    int roll = rand() % 8 + 1;
    return roll;
}

int Game::RollD6()
{
    srand(time(NULL));
    int roll = rand() % 6 + 1;
    return roll;
}

int Game::RollD4()
{
    srand(time(NULL));
    int roll = rand() % 4 + 1;
    return roll;
}

int Game::split(string sString, char separator, string arr[], int size) // split function based on provided separator for reading text files with game information
{
    int arrIDX = 0;
    if (sString == "")
    {
        return arrIDX;
    }
    string temp =  "";
    sString += separator;
    for (int i = 0; i < sString.length(); i++)
    {
        if (sString[i] != separator)
        {
            temp += sString[i];
        }
        else
        {
            arr[arrIDX] = temp;
            arrIDX++;
            temp = "";
        }
        if (arrIDX > size)
        {
            return -1;
        }
    }
    return arrIDX;
}

void Game::takeInventory()
{
    cout << "Player Arsenal: " << endl;
    for (int i = 0; i < 4; i++)
    {
        cout << arsenal.at(i).getWeaponName() << endl;
    }
    cout << endl;
    int count;
    string test = "";

    // cout << endl;
    // int size = playerInventory.size();//test 
    // for (int i = 0; i < size; i++)
    // {
    //     cout << playerInventory.at(i).getItemName() << endl;
    // }
    // cout << endl;

    cout << "Current Inventory: " << endl;
    for (int i = 0; i < 1; i++)
    {
        count = 0;
        test = availableItems.at(i).getItemName();
        for (int j = 0; j < playerInventory.size(); j++)
        {
            if (test == playerInventory.at(j).getItemName())
            {
                count++;
            }
        }
        cout << test << ": " << count << endl;
    }
    int HS = player.getHackSilver();
    int AoE = player.getAppleOfEdun();
    int SS = player.getSkapSlag();
    int DoWT = player.getWorldTreeDew();
    int AS = player.getAsgardianSteel();

    cout << "Hacksilver: " << HS << endl;
    cout << "Apples Of Edun: " << AoE << endl;
    cout << "Skapslag: " << SS << endl;
    cout << "Dew Of The World Tree: " << DoWT << endl;
    cout << "Asgardian Steel: " << AS << endl;
}