// CSCI1300 Fall 2020
// Author: Miles Sanders
// Recitation 305
#include "Weapons.h"
#include <iostream>
#include <string>

using namespace std;

Weapons::Weapons()
{
    Damage weaponstats;
    weaponName = "";
    weaponBase = 0;
    weaponFrost = 0;
    weaponFire = 0;
    weaponStun = 0;
    weaponboost = "";
}

Weapons::Weapons(string Name, int bD, int sD, int fireD, int frostD, string boost)
{
    Damage weaponstats;
    weaponName = Name;
    weaponstats.setbaseDamage(bD);
    weaponstats.setfrostDamage(frostD);
    weaponstats.setfireDamage(fireD);
    weaponstats.setstunDamage(sD);
    weaponBase = weaponstats.getbaseDamage();
    weaponFrost = weaponstats.getfrostDamage();
    weaponFire = weaponstats.getfireDamage();
    weaponStun = weaponstats.getstunDamage();
    weaponboost = boost;
}

string Weapons::getWeaponName()
{
    return weaponName;
}
void Weapons::setWeaponName(string Name)
{
    weaponName = Name;
}
int Weapons::getWeaponBaseDamage()
{
    return weaponBase;
}
void Weapons::setWeaponBaseDamage(int bD)
{
    weaponBase = bD;
}
int Weapons::getWeaponStunDamage()
{
    return weaponStun;
}
void Weapons::setWeaponStunDamage(int sD)
{
    weaponStun = sD;
}
int Weapons::getWeaponFireDamage()
{
    return weaponFire;
}
void Weapons::setWeaponFireDamage(int fireD)
{
    weaponFire = fireD;
}
int Weapons::getWeaponFrostDamage()
{
    return weaponFrost;
}
void Weapons::setWeaponFrostDamage(int frostD)
{
    weaponFrost = frostD;
}

string Weapons::getWeaponBoost()
{
    return weaponboost;
}

void Weapons::setWeaponBoost(string boost)
{
    weaponboost = boost;
}