// CSCI1300 Fall 2020
// Author: Miles Sanders
// Recitation 305
#include "Game.h"
#include <iostream>
#include <string>

using namespace std;

int main()
{
    Game game;
    bool flag = false;
    while (flag == false)
    {
        cout << "Run Game?" << endl;
        cout << "1. Yes" << endl;
        cout << "2. No" << endl;
        string input;
        getline(cin, input);
        int num = stoi(input);
        if (num != 1 && num != 2)
        {
            cout << "Invalid input." << endl;
        }
        if (num == 2)
        {
            cout << "ok" << endl;
        }
        if (num == 1)
        {
            game = Game(); //creates game object that can have variables assigned
            game.loadFile(); //loads in text file information on objects
            game.menu(); //primary interface for player
        }
    }
    return 0;
}