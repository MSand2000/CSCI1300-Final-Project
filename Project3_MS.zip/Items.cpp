// CSCI1300 Fall 2020
// Author: Miles Sanders
// Recitation 305
#include "Items.h"
#include <iostream>
#include <string>

using namespace std;

Items::Items()
{
    ItemName = "";
    ImprovementValue = 0;
}
Items::Items(string itemName, int improvementValue)
{
    ItemName = itemName;
    ImprovementValue = improvementValue;
}

string Items::getItemName()
{
    return ItemName;
}
void Items::setItemName(string itemName)
{
    ItemName = itemName;
}
int Items::getImprovementValue()
{
    return ImprovementValue;
}
void Items::setImprovementValue(int improvementValue)
{
    ImprovementValue = improvementValue;    
}