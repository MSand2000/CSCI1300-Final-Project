// CSCI1300 Fall 2020
// Author: Miles Sanders
// Recitation 305
#ifndef PLAYER_H
#define PLAYER_H


#include <string>
using namespace std;
class Player
{
    public:
    //constructors
    Player();
    Player(int H, int A, int D, int HS, int AE, int SS, int WTD, int AS);

    //getters
    int getMaxHealth();
    int getCurrentHealth();
    int getArmorRating();
    int getDamageRating();
    int getHackSilver();
    int getAppleOfEdun();    
    int getSkapSlag();
    int getWorldTreeDew();
    int getAsgardianSteel();

    //setters
    void setMaxHealth(int H);
    void setCurrentHealth(int C);
    void setArmorRating(int A);
    void setDamageRating(int D);
    void setHackSilver(int HS);
    void setAppleOfEdun(int AE);
    void setSkapSlag(int SS);
    void setWorldTreeDew(int WTD);
    void setAsgardianSteel(int AS);

    //helpers
    void addHealth(int C);
    

    private:
    int hacksilver;
    int appleOfEdun;
    int skapSlag;
    int worldTreeDew;
    int asgardianSteel;
    int maxHealth;
    int currentHealth;
    int armorRating;
    int damageRating;
};
#endif 