// CSCI1300 Fall 2020
// Author: Miles Sanders
// Recitation 305
#include "Enemies.h"
#include <iostream>
#include <string>

using namespace std;

Enemies::Enemies()
{
    EnemyType = "";
    EnemyBoost = "";
    EnemyWeakness = "";
    EnemyDamageRating = 0;
    EnemyBaseDamage = 0;
    EnemyBoostDamage = 0;
    EnemyArmorRating = 0;
    EnemyMaxHealth = 0;
    EnemyCurrentHealth = 0;
}

Enemies::Enemies(string enemyType, string enemyBoost, string enemyWeakness, 
int enemyDamageRating, int enemyBaseDamage, int enemyBoostDamage, 
int enemyArmorRating, int enemyMaxHealth)
{
    EnemyType = enemyType;
    EnemyBoost = enemyBoost;
    EnemyWeakness = enemyWeakness;
    EnemyDamageRating = enemyDamageRating;
    EnemyBaseDamage = enemyBaseDamage;
    EnemyBoostDamage = enemyBoostDamage;
    EnemyArmorRating = enemyArmorRating;
    EnemyMaxHealth = enemyMaxHealth;
    EnemyCurrentHealth = enemyMaxHealth;
}

string Enemies::getEnemyType()
{
    return EnemyType;
}
void Enemies::setEnemyType(string enemyType)
{
    EnemyType = enemyType;
}
string Enemies::getEnemyBoost()
{
    return EnemyBoost;
}
void Enemies::setEnemyBoost(string enemyBoost)
{
    EnemyBoost = enemyBoost;
}
string Enemies::getEnemyWeakness()
{
    return EnemyWeakness;
}
void Enemies::setEnemyWeakness(string enemyWeakness)
{
    EnemyWeakness = enemyWeakness;
}
int Enemies::getEnemyDamageRating()
{
    return EnemyDamageRating;
}
void Enemies::setEnemyDamageRating(int enemyDamageRating)
{
    EnemyDamageRating = enemyDamageRating;
}
int Enemies::getEnemyBaseDamage()
{
    return EnemyBaseDamage;
}
void Enemies::setEnemyBaseDamage(int enemyBaseDamage)
{
    EnemyBaseDamage = enemyBaseDamage;
}
int Enemies::getEnemyBoostDamage()
{
    return EnemyBoostDamage;
}
void Enemies::setEnemyBoostDamage(int enemyBoostDamage)
{
    EnemyBoostDamage = enemyBoostDamage;
}
int Enemies::getEnemyArmorRating()
{
    return EnemyArmorRating;
}
void Enemies::setEnemyArmorRating(int enemyArmorRating)
{
    EnemyArmorRating = enemyArmorRating;
}
int Enemies::getEnemyMaxHealth()
{
    return EnemyMaxHealth;
}
void Enemies::setEnemyMaxHealth(int enemyMaxHealth)
{
    EnemyMaxHealth = enemyMaxHealth;
}
int Enemies::getEnemyCurrentHealth()
{
    return EnemyCurrentHealth;
}
void Enemies::setEnemyCurrentHealth(int C)
{
    EnemyCurrentHealth = EnemyCurrentHealth - C;
}